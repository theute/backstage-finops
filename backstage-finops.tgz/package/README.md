# finops

Backstage frontend plugin for Cloud Resources Attribution (CRA).

## Route

This plugin is mounted at `http://localhost:3000/finops` (path: `/finops`).

## API configuration

The plugin fetches data through Backstage proxy:

`/api/proxy/finops/api/*` -> `${FINOPS_CRA_API_URL}`

Backstage proxy forwards an auth header from environment:

- `FINOPS_CRA_API_URL`
- `FINOPS_CRA_API_TOKEN` (must include the prefix, for example `Basic ...`)

Example local setup:

```bash
export FINOPS_CRA_API_URL="https://your-cra-api.example.com"
export FINOPS_CRA_API_TOKEN="Basic <base64-credentials>"
yarn start
```

Do not commit raw credentials or tokens to git. Keep token values in environment
variables or secret management for your runtime platform.

After changing the Scope Cost API, redeploy that service and confirm it serves new routes, for example:

`curl -sS -H "Authorization: …" "${FINOPS_CRA_API_URL%/}/api/teams"`

## Scope Cost API contract

The upstream Scope Cost API in the `cloud-resources-attribution` webapp exposes:

- `GET /api/teams` — `id` (team config path), `name`, optional `description`, `members` with `person_id` and `role` (`manager` | `product_manager` | `team_lead`)
- `GET /api/scopes` — `scope_slug`, `scope_name`, optional query `team`: allocated scope slugs **and all nested slugs** (`child` matches `root` or `root.%`)
- `GET /api/trends` — query: `from`, `to`, `metric`, `grain`, optional `scope`, optional `team`
- `GET /api/summary` — query: `from`, `to`, `metric`, optional `scope`, optional `team`

Provider-type filtering in the Backstage UI is **client-side only** (the API does not accept `provider_types`).

The CRA page overlays **usage hours** on the cost chart. The live data source calls the trends API separately for `ec2_usage_hours_amount` and `rds_usage_hours_amount`, and renders each metric as its own usage series. The Scope Cost API `metric` query parameter accepts those column names alongside cost metrics.
